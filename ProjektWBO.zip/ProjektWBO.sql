use ProjektSI;

Select distinct Lp, PARSENAME(Replace(Data,',','.'), 1) AS DataZlozenia, PARSENAME(Replace(Data,',','.'), 2) AS Godzina,  Wiek, Plec, Osiedle, Kod_Pocztowy, Zrodlo, Prog_1, Prog_2, Prog_3, k.Miejsc, k.POWIAT, 
	cast(( Select T.Adres + ','
	from kody T
	Where v.Kod_Pocztowy = T.KodPoczt
	For xml path('')) as varchar(max)) as adres
from votes_with_city_wojewodztwo v
left join kody k on k.KodPoczt = v.Kod_Pocztowy
order by Lp
;

select * from kody;

insert into Temp(Data, Godzina,  Wiek, Plec, Osiedle, KodPocztowy, Zrodlo, Prog1, Prog2, Prog3, Miejscowosc, Powiat, Adres)
Select distinct PARSENAME(Replace(Data,',','.'), 1) AS DataZlozenia, PARSENAME(Replace(Data,',','.'), 2) AS Godzina,  Wiek, Plec, Osiedle, Kod_Pocztowy, Zrodlo, Prog_1, Prog_2, Prog_3, k.Miejsc, k.POWIAT, 
	cast(( Select T.Adres + ','
	from kody T
	Where v.Kod_Pocztowy = T.KodPoczt
	For xml path('')) as varchar(max)) as adres
from votes_with_city_wojewodztwo v
left join kody k on k.KodPoczt = v.Kod_Pocztowy
;




create table Temp (
VoteId int identity(1,1) Primary Key,
Data  varchar(255),
Godzina  varchar(255),
Wiek int,
Plec char(1),
Osiedle varchar(255),
KodPocztowy char(6),
Zrodlo char(1),
Prog1 int,
Prog2 int,
Prog3 int,
Miejscowosc  varchar(255),
Powiat  varchar(255),
Adres  varchar(MAX),
);


Alter table Temp
alter column Godzina time;

Update Temp
Set Data = Replace(Data,'-','/')

create table dim_time
(
VoteTimeId int identity(1,1) Primary Key,
Godzina time
);

insert into dim_time(Godzina)
Select distinct Godzina from Temp;

alter table Temp
add LocationId int, VoteTimeId int;

update Temp 
	Set VoteTimeId = d.VoteTimeId
	--Set LocationId = null
	From Temp t
	join dim_time d on t.Godzina = d.Godzina;

alter table Temp add foreign key (VoteTimeId) references dim_time(VoteTimeId);

create table dim_date
(
VoteDateId int identity(1,1) Primary Key,
Data date
);
set dateformat dmy;
select cast(Data as date) from Temp; 

insert into  dim_date(Data)
select distinct cast(Data as date) from Temp; 

alter table Temp
 add VoteDateId int;

update Temp 
	Set VoteDateId = d.VoteDateId
	--Set LocationId = null
	From Temp t
	join dim_date d on t.Data = d.Data;

alter table Temp add foreign key (VoteDateId) references dim_date(VoteDateId);

create table dim_location(
VoteLocationId int identity(1,1) Primary Key,
Miasto varchar(255),
Powiat varchar(255),
Adres varchar(MAX),
Osiedle varchar(255),
KodPocztowy varchar(255)
);

insert into dim_location(Miasto, Powiat, Adres, Osiedle, KodPocztowy)
select Miejscowosc, Powiat, Adres, Osiedle, KodPocztowy from Temp;

update Temp 
	Set LocationId = d.VoteLocationId
	--Set LocationId = null
	From Temp t
	join dim_location d on t.KodPocztowy = d.KodPocztowy;

alter table Temp add foreign key (LocationId) references dim_location(VoteLocationId);

create table dim_person(
VotePersonId int identity(1,1) Primary Key,
Wiek int,
Plec Char(1)
);

insert into dim_person(Wiek, Plec)
select distinct Wiek,Plec from Temp;
alter table temp
add PersonId int;

update Temp 
	Set PersonId = d.VotePersonId
	--Set LocationId = null
	From Temp t
	join dim_person d on t.Wiek = d.Wiek and t.Plec = d.Plec;

alter table Temp add foreign key (PersonId) references dim_person(VotePersonId);
alter table Temp
drop column Wiek, Plec, Data, Godzina, Osiedle, KodPocztowy, Miejscowosc, Powiat, Adres;
Exec sp_rename 'Temp', 'fact_vote';

delete from dim_location where KodPocztowy = '';

select * from dim_date;
select * from dim_location;
select * from dim_person;
select * from dim_time;
select * from fact_vote;